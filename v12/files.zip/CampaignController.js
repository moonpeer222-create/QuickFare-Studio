/**
 * Campaign Controller
 * Handles AI campaign generation logic
 * Separates business logic from UI/API calls
 */

import { appState } from './appState.js';
import { canvasManager } from './CanvasManager.js';
import { AIService } from './services/AIService.js';
import { showToast } from './ui.js';

export class CampaignController {
    /**
     * Generate marketing campaign using AI
     */
    static async generateCampaign(topic) {
        if (!topic || topic.trim() === '') {
            showToast('Please enter a topic first', true);
            return null;
        }

        appState.setLoading(true, 'Generating campaign...');

        try {
            const campaign = await this.createCampaignWithAI(topic);
            appState.setLoading(false);
            appState.clearError();
            return campaign;
        } catch (error) {
            appState.setLoading(false);
            appState.setError(error);
            
            // Try fallback
            try {
                const fallbackCampaign = this.createFallbackCampaign(topic);
                showToast('Using offline fallback campaign', false);
                return fallbackCampaign;
            } catch (fallbackError) {
                showToast(`Error: ${error.message}`, true);
                return null;
            }
        }
    }

    /**
     * Create campaign using AI API
     * @private
     */
    static async createCampaignWithAI(topic) {
        const systemPrompt = `You are an expert marketing copywriter. Produce elite marketing copy formatted EXACTLY like this:

<h4>🔥 VIRAL TRIGGER HOOK</h4>
<p>[single powerful hook sentence]</p>

<h4>🧠 DIRECT AD FRAMEWORK</h4>
<p><b>PROBLEM MAP:</b> [the core problem]\n<b>AGGRESSION LIMIT:</b> [urgency/action needed]\n<b>SOLUTION ROADMAP:</b> [your solution]</p>

<h4>🎯 DEMOGRAPHIC TARGET DIRECTIVES</h4>
<p>#hashtag1 #hashtag2 #hashtag3</p>

<h4>🖼️ VISUAL INITIATION NODE</h4>
<p>Target System Background String Output : [exactly 3 visual descriptors separated by spaces]</p>

Keep it concise, powerful, and actionable.`;

        const userPrompt = `Create an elite marketing campaign for: ${topic}`;

        // Call AI service
        const response = await AIService.generateCompletion('meta-llama/llama-3-8b-instruct:free', systemPrompt, userPrompt);

        // Parse response
        return this.parseCampaignResponse(response, topic);
    }

    /**
     * Parse AI response into campaign object
     * @private
     */
    static parseCampaignResponse(html, topic) {
        const campaign = {
            topic,
            hook: '',
            problem: '',
            aggression: '',
            solution: '',
            hashtags: [],
            imageQuery: '',
            rawHtml: html
        };

        // Extract hook
        const hookMatch = /<h4>🔥[\s\S]*?<\/h4>[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/i.exec(html);
        if (hookMatch) {
            campaign.hook = this.cleanHTML(hookMatch[1]);
        }

        // Extract framework
        const problemMatch = /PROBLEM MAP:<\/b>\s*([\s\S]*?)(?:\n|<br|AGGRESSION)/i.exec(html);
        const aggressionMatch = /AGGRESSION LIMIT:<\/b>\s*([\s\S]*?)(?:\n|<br|SOLUTION)/i.exec(html);
        const solutionMatch = /SOLUTION ROADMAP:<\/b>\s*([\s\S]*?)(?:\n|<\/p>|<br)/i.exec(html);

        campaign.problem = problemMatch ? this.cleanHTML(problemMatch[1]) : '';
        campaign.aggression = aggressionMatch ? this.cleanHTML(aggressionMatch[1]) : '';
        campaign.solution = solutionMatch ? this.cleanHTML(solutionMatch[1]) : '';

        // Extract hashtags
        const hashtagMatch = /🎯[\s\S]*?<p[^>]*>(.*?)<\/p>/i.exec(html);
        if (hashtagMatch) {
            const hashtagString = hashtagMatch[1];
            campaign.hashtags = hashtagString.match(/#[\w]+/g) || [];
        }

        // Extract image search query
        const imageMatch = /VISUAL INITIATION NODE[\s\S]*?:[\s\S]*?<span[^>]*>(.*?)<\/span>/i.exec(html);
        if (imageMatch) {
            campaign.imageQuery = this.cleanHTML(imageMatch[1]).trim();
        }

        return campaign;
    }

    /**
     * Create fallback campaign when AI fails
     * @private
     */
    static createFallbackCampaign(topic) {
        const campaigns = {
            'finance': {
                hook: 'Your current setup is literally bleeding money. Fix it in 3 clicks.',
                problem: 'Physical scaling burns through cash',
                aggression: 'Action takers consume entire segments daily',
                solution: 'Deploy digital-first scaling system',
                hashtags: ['#ScaleDigitally', '#NoInventory', '#Ecommerce'],
                imageQuery: 'luxury business abstract dark'
            },
            'fitness': {
                hook: 'Everything they told you about calories is mathematically wrong.',
                problem: 'Diet industries sell lies, not results',
                aggression: 'Your body responds only to scientific truth',
                solution: 'Follow the bio-hacking formula inside',
                hashtags: ['#RealFitness', '#BioHacking', '#DietFacts'],
                imageQuery: 'dark green healthy organic food'
            },
            'default': {
                hook: 'If you don\'t execute this formula today, someone else will.',
                problem: 'Stagnation is equal to deletion in the modern era',
                aggression: 'Market leaders move fast and relentlessly',
                solution: 'Deploy the automation sequence inside',
                hashtags: ['#FutureProof', '#SystemScale', '#Automation'],
                imageQuery: 'Dark futuristic neon space'
            }
        };

        const keyword = Object.keys(campaigns).find(key => 
            topic.toLowerCase().includes(key)
        ) || 'default';

        return {
            topic,
            ...campaigns[keyword]
        };
    }

    /**
     * Apply campaign to canvas
     */
    static applyCampaignToCanvas(campaign) {
        if (!campaign) {
            showToast('No campaign to apply', true);
            return;
        }

        try {
            // Clear existing
            canvasManager.clearAll();

            // Add hook as heading
            canvasManager.addText({
                text: campaign.hook.toUpperCase(),
                top: '80px',
                left: '50px',
                width: '900px',
                fontSize: '60px',
                fontFamily: 'Anton',
                color: '#00F0FF'
            });

            // Add framework as card
            const frameworkText = `
PROBLEM: ${campaign.problem}

ACTION: ${campaign.aggression}

SOLUTION: ${campaign.solution}

${campaign.hashtags.join(' ')}
            `.trim();

            canvasManager.addCard({
                text: frameworkText,
                top: '300px',
                left: '50px',
                width: '900px',
                backgroundColor: 'rgba(18,20,25,0.95)'
            });

            appState.saveCanvasState();
            showToast('Campaign applied to canvas!');
            return true;
        } catch (error) {
            showToast(`Failed to apply campaign: ${error.message}`, true);
            appState.setError(error);
            return false;
        }
    }

    /**
     * Clean HTML text
     * @private
     */
    static cleanHTML(text) {
        // Remove HTML tags
        let clean = text.replace(/<[^>]*>/g, '');
        // Decode entities
        clean = clean
            .replace(/&nbsp;/g, ' ')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&amp;/g, '&');
        return clean.trim();
    }
}

// Expose to window for HTML event handlers
window.CampaignController = CampaignController;
