/**
 * UI Utilities
 * Helper functions for DOM manipulation and notifications
 */

import { appState } from './appState.js';

// ============ TOAST NOTIFICATIONS ============

/**
 * Show toast notification
 * @param {string} message - Notification message
 * @param {boolean} isError - Whether this is an error notification
 * @param {number} duration - Duration in milliseconds
 */
export function showToast(message, isError = false, duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `toast ${isError ? 'toast-error' : 'toast-success'}`;
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 16px 24px;
        background-color: ${isError ? '#dc3545' : '#28a745'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        font-size: 14px;
        z-index: 9999;
        animation: slideInUp 0.3s ease;
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOutDown 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ============ MODAL DIALOGS ============

/**
 * Show confirmation dialog
 * @param {string} message - Dialog message
 * @param {string} title - Dialog title
 * @returns {Promise<boolean>} User choice
 */
export async function showConfirmDialog(message, title = 'Confirm') {
    return new Promise((resolve) => {
        const dialog = document.createElement('div');
        dialog.className = 'modal-overlay';
        dialog.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        `;

        dialog.innerHTML = `
            <div style="background: white; padding: 30px; border-radius: 12px; max-width: 400px;">
                <h3 style="margin: 0 0 15px 0;">${title}</h3>
                <p style="margin: 0 0 25px 0; color: #666;">${message}</p>
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button class="btn" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
                    <button class="btn btn-primary" onclick="this.closest('.modal-overlay').dataset.confirmed='true'; this.closest('.modal-overlay').remove();">Confirm</button>
                </div>
            </div>
        `;

        dialog.addEventListener('mousedown', (e) => {
            if (e.target === dialog) {
                resolve(false);
                dialog.remove();
            }
        });

        document.body.appendChild(dialog);

        // Monitor for completion
        const checkInterval = setInterval(() => {
            if (!document.contains(dialog)) {
                clearInterval(checkInterval);
                resolve(dialog.dataset.confirmed === 'true');
            }
        }, 50);
    });
}

/**
 * Show alert dialog
 * @param {string} message - Alert message
 * @param {string} title - Dialog title
 * @returns {Promise<void>}
 */
export function showAlertDialog(message, title = 'Alert') {
    return new Promise((resolve) => {
        const dialog = document.createElement('div');
        dialog.className = 'modal-overlay';
        dialog.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        `;

        dialog.innerHTML = `
            <div style="background: white; padding: 30px; border-radius: 12px; max-width: 400px;">
                <h3 style="margin: 0 0 15px 0;">${title}</h3>
                <p style="margin: 0 0 25px 0; color: #666;">${message}</p>
                <button class="btn btn-primary" style="width: 100%;" onclick="this.closest('.modal-overlay').remove();">OK</button>
            </div>
        `;

        document.body.appendChild(dialog);

        const checkInterval = setInterval(() => {
            if (!document.contains(dialog)) {
                clearInterval(checkInterval);
                resolve();
            }
        }, 50);
    });
}

// ============ DOM SELECTORS ============

/**
 * Select element by ID (shorthand)
 * @param {string} id - Element ID
 * @returns {HTMLElement}
 */
export function byId(id) {
    return document.getElementById(id);
}

/**
 * Select element by CSS selector
 * @param {string} selector - CSS selector
 * @returns {HTMLElement}
 */
export function select(selector) {
    return document.querySelector(selector);
}

/**
 * Select all elements by CSS selector
 * @param {string} selector - CSS selector
 * @returns {NodeList}
 */
export function selectAll(selector) {
    return document.querySelectorAll(selector);
}

// ============ ELEMENT UTILITIES ============

/**
 * Show element
 */
export function show(element) {
    if (element) element.style.display = 'block';
}

/**
 * Hide element
 */
export function hide(element) {
    if (element) element.style.display = 'none';
}

/**
 * Toggle element visibility
 */
export function toggle(element) {
    if (element) element.style.display = element.style.display === 'none' ? 'block' : 'none';
}

/**
 * Add class to element
 */
export function addClass(element, className) {
    if (element) element.classList.add(className);
}

/**
 * Remove class from element
 */
export function removeClass(element, className) {
    if (element) element.classList.remove(className);
}

/**
 * Toggle class on element
 */
export function toggleClass(element, className) {
    if (element) element.classList.toggle(className);
}

// ============ FORM UTILITIES ============

/**
 * Get input value
 */
export function getInputValue(id) {
    const element = byId(id);
    return element ? element.value : '';
}

/**
 * Set input value
 */
export function setInputValue(id, value) {
    const element = byId(id);
    if (element) element.value = value;
}

/**
 * Disable element
 */
export function disable(element) {
    if (element) element.disabled = true;
}

/**
 * Enable element
 */
export function enable(element) {
    if (element) element.disabled = false;
}

// ============ EVENT HANDLING ============

/**
 * Add event listener with cleanup
 * @returns {Function} Cleanup function
 */
export function on(element, event, handler) {
    if (element) {
        element.addEventListener(event, handler);
        return () => element.removeEventListener(event, handler);
    }
    return () => {};
}

/**
 * Delegate event handler
 */
export function delegate(element, selector, event, handler) {
    if (!element) return;
    
    element.addEventListener(event, (e) => {
        const target = e.target.closest(selector);
        if (target) {
            handler.call(target, e);
        }
    });
}

// ============ LOADING STATE ============

/**
 * Show loading indicator
 */
export function showLoading(message = 'Loading...') {
    const loader = document.createElement('div');
    loader.id = 'global-loader';
    loader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0,0,0,0.7);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;

    loader.innerHTML = `
        <div style="color: white; text-align: center;">
            <div style="
                border: 4px solid rgba(255,255,255,0.3);
                border-top: 4px solid white;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin-bottom: 20px;
            "></div>
            <p style="margin: 0; font-size: 16px;">${message}</p>
        </div>
    `;

    document.body.appendChild(loader);
}

/**
 * Hide loading indicator
 */
export function hideLoading() {
    const loader = byId('global-loader');
    if (loader) loader.remove();
}

// ============ THEME MANAGEMENT ============

/**
 * Toggle between light and dark theme
 */
export function toggleTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
    const newTheme = isDark ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    appState.ui.theme = newTheme;
    appState.notify('ui');
    
    return newTheme;
}

/**
 * Get current theme
 */
export function getCurrentTheme() {
    return document.documentElement.getAttribute('data-theme') || 'dark';
}

/**
 * Initialize theme from localStorage
 */
export function initializeTheme() {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
}

// ============ CLIPBOARD ============

/**
 * Copy text to clipboard
 */
export async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('Copied to clipboard!');
        return true;
    } catch (error) {
        showToast('Failed to copy', true);
        return false;
    }
}

// ============ UTILITIES ============

/**
 * Debounce function
 */
export function debounce(fn, delay) {
    let timeoutId;
    return function(...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn(...args), delay);
    };
}

/**
 * Throttle function
 */
export function throttle(fn, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            fn.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}
