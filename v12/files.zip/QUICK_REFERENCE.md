# QuickFare Studio: Before & After Quick Reference

## Global Functions → Module Methods

### Add Text Element

**BEFORE** ❌
```javascript
// Global function with many parameters
window.addTextObj = function(htm, tp, lft, wd, fs, fm, cl="#fff", ls="0px", lh="1.1", al="left", stk="0px transparent") {
    let dv = document.createElement('div');
    dv.className = 'element el-text';
    dv.id = 'el-' + window.elCount++;
    // ... 15 more lines
}

// Used in HTML:
<button onclick="addTextObj('Hello', '100px', '80px', '800px', '60px', 'Anton')">Add Text</button>
```

**AFTER** ✅
```javascript
// Clean method with object config
canvasManager.addText({
    text: 'Hello',
    top: '100px',
    left: '80px',
    width: '800px',
    fontSize: '60px',
    fontFamily: 'Anton'
})

// Used in HTML:
<button onclick="canvasManager.addText({ text: 'Hello', top: '100px', left: '80px', width: '800px', fontSize: '60px', fontFamily: 'Anton' })">Add Text</button>
```

---

### Clear Canvas

**BEFORE** ❌
```javascript
window.clearCanvasElements = function() {
    artboard.querySelectorAll('.element').forEach(z => z.remove());
    saveState();
}

// HTML:
<button onclick="clearCanvasElements()">Clear</button>
```

**AFTER** ✅
```javascript
canvasManager.clearAll()

// HTML:
<button onclick="canvasManager.clearAll()">Clear</button>
```

---

### Add Image

**BEFORE** ❌
```javascript
window.addImage = function(url, tp, lft, wd, br="0px") {
    let mg = document.createElement('img');
    mg.crossOrigin = 'anonymous';
    mg.className = 'element el-image';
    mg.id = 'el-' + window.elCount++;
    mg.src = url;
    mg.style.top = tp;
    mg.style.left = lft;
    // ... more style assignments
}

// HTML:
<button onclick="addImage('http://...', '100px', '80px', '400px')">Add Image</button>
```

**AFTER** ✅
```javascript
canvasManager.addImage({
    url: 'http://...',
    top: '100px',
    left: '80px',
    width: '400px'
})

// HTML:
<button onclick="canvasManager.addImage({ url: 'http://...', top: '100px', left: '80px', width: '400px' })">Add Image</button>
```

---

### Export Canvas

**BEFORE** ❌
```javascript
window.exportDesign = function() {
    html2canvas(document.getElementById('artboard'), {
        backgroundColor: '#ffffff',
        scale: 2,
        useCORS: true
    }).then(canvas => {
        canvas.toBlob(blob => {
            let link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'design.png';
            link.click();
        });
    }).catch(err => console.error(err));
}

// HTML:
<button onclick="exportDesign()">Download</button>
```

**AFTER** ✅
```javascript
canvasManager.downloadAsImage('my-design', 'image/png')

// HTML:
<button onclick="canvasManager.downloadAsImage('my-design', 'image/png')">Download</button>
```

---

## State Management

### Global State → Centralized State

**BEFORE** ❌
```javascript
// Scattered everywhere
window.elCount = 1000;
window.mxZ = 20;
window.selectedEl = null;

// Updated randomly:
window.elCount++;
window.mxZ++;
selectedEl = el;

// Hard to debug - state is everywhere
```

**AFTER** ✅
```javascript
// Single source of truth
appState.canvas.elementCount = 1000;
appState.canvas.maxZIndex = 20;
appState.canvas.selectedElement = null;

// Organized updates:
appState.addCanvasElement({...})
appState.selectElement(id)
appState.updateCanvasElement(id, {...})

// Easy to debug:
console.log(appState.getSnapshot())
```

---

### State Subscription

**BEFORE** ❌
```javascript
// No reactive updates
// Have to manually update UI when state changes
function updateUI() {
    document.getElementById('count').textContent = window.elCount;
}
// But nobody calls this consistently
```

**AFTER** ✅
```javascript
// Reactive updates
appState.subscribe('canvas', (canvasState) => {
    document.getElementById('count').textContent = canvasState.elements.length;
});

// UI updates automatically when state changes!
appState.addCanvasElement(...) // UI updates instantly
```

---

## Error Handling

### Old Approach → New Approach

**BEFORE** ❌
```javascript
async function triggerAICampaign() {
    try {
        let completion = await AIService.generateCompletion(...);
        // ...
    } catch (err) {
        console.warn("Error..."); // Silently logs
        // Try fallback without telling user
    }
}
```

**AFTER** ✅
```javascript
async function generateCampaign(topic) {
    appState.setLoading(true, 'Generating...');
    
    try {
        const campaign = await AIService.generateCompletion(...);
        appState.setLoading(false);
        appState.clearError();
        return campaign;
    } catch (error) {
        appState.setLoading(false);
        appState.setError(error);  // Stores error in state
        showToast(`Error: ${error.message}`, true); // User sees it
        
        // Try fallback
        return this.createFallbackCampaign(topic);
    }
}
```

---

## UI Utilities

### Toast Notifications

**BEFORE** ❌
```javascript
// Inline in function
alert("Something happened!");  // Ugly browser alert

// OR custom HTML
let toast = document.createElement('div');
toast.textContent = "Success!";
toast.style.cssText = '...lots of CSS...';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
```

**AFTER** ✅
```javascript
import { showToast } from './js/ui.js';

// One line, clean
showToast('Canvas cleared!');
showToast('Error occurred', true);  // Error style
showToast('Copying...', false, 2000);  // Custom duration
```

---

### Modal Dialogs

**BEFORE** ❌
```javascript
// Browser confirm - ugly and inflexible
if (confirm('Clear canvas?')) {
    clearCanvasElements();
}
```

**AFTER** ✅
```javascript
import { showConfirmDialog } from './js/ui.js';

const confirmed = await showConfirmDialog(
    'This action cannot be undone',
    'Clear Canvas?'
);

if (confirmed) {
    canvasManager.clearAll();
}
```

---

## Campaign Generation

### Old Flow → New Flow

**BEFORE** ❌
```javascript
window.triggerAICampaign = async function() {
    let tp = document.getElementById('ai-topic-strategy').value;
    let bx = document.getElementById('ai-results');
    
    bx.innerHTML = `<div>Loading...</div>`;  // DOM manipulation
    
    try {
        let completion = await AIService.generateCompletion(...);  // API call
        let dirtyHtml = completion.replace(/```/gi,'');  // String manipulation
        bx.innerHTML = dirtyHtml + `<button onclick="applyAIResultsToCanvas()">Apply</button>`;  // More DOM
        
        let findImageDesc = /Output[\s\S]*?:([^<]+)<\/p>/i.exec(dirtyHtml);  // Regex parsing
        if(findImageDesc) {
            document.getElementById('pexels-search').value = findImageDesc[1];
            window.fetchPexels(false);  // Cross-layer call
        }
    } catch (err) {
        console.warn("Fallback...");
        // ... fallback logic mixed in
    }
}

window.applyAIResultsToCanvas = function() {
    const hook = document.getElementById('ai-hook')?.innerText;
    if(!hook) return;
    
    addTextObj(hook, ...);  // More global functions
    addCardObj(hook, ...);
    saveState();
    showToast("Applied!");
}
```

**AFTER** ✅
```javascript
// Clean separation of concerns

// 1. Business logic (CampaignController)
async function generateCampaign(topic) {
    const campaign = await CampaignController.generateCampaign(topic);
    return campaign;
}

// 2. Display results
function displayResults(campaign) {
    const html = `
        <div class="campaign-results">
            <h4>Hook</h4>
            <p>${campaign.hook}</p>
            <button onclick="applyCampaign()">Apply</button>
        </div>
    `;
    document.getElementById('ai-results').innerHTML = html;
    window.currentCampaign = campaign;
}

// 3. Apply to canvas
function applyCampaign() {
    CampaignController.applyCampaignToCanvas(window.currentCampaign);
}

// HTML:
<button onclick="generateAndDisplay()">Generate</button>

<script>
async function generateAndDisplay() {
    const topic = document.getElementById('ai-topic-strategy').value;
    const campaign = await generateCampaign(topic);
    if (campaign) displayResults(campaign);
}
</script>
```

---

## Code Organization

### File Structure

**BEFORE** ❌
```
js/
├── api.js           (410 LOC - everything mixed)
├── canvas.js        (255 LOC - canvas + utils)
├── ui.js            (246 LOC - UI + DOM)
├── state.js         (165 LOC - state scattered)
├── config.js        (83 LOC)
└── services/
    ├── AIService.js
    ├── PexelsService.js
    └── CanvaService.js

Problem: Circular dependencies, hard to test, unclear where to add features
```

**AFTER** ✅
```
js/
├── appState.js                 (State only, ~250 LOC)
├── CanvasManager.js            (Canvas only, ~300 LOC)
├── CampaignController.js       (Business logic only, ~200 LOC)
├── ui.js                       (UI utils only, ~200 LOC)
├── services/                   (External APIs)
│   ├── AIService.js
│   ├── PexelsService.js
│   └── CanvaService.js
└── config.js                   (Constants)

Benefits: Clear responsibility, easy to test, obvious where to add features
```

---

## Performance

### Before vs After

**BEFORE** ❌
- 50+ global functions on `window`
- State scattered everywhere
- No undo/redo support
- localStorage not utilized
- Inefficient DOM queries

**AFTER** ✅
- Only 3 modules exposed (`appState`, `canvasManager`, `CampaignController`)
- Centralized state
- Built-in undo/redo
- Auto-saves to localStorage
- Cached DOM references

**Result**: 
- Cleaner memory usage
- Faster startup
- Better debugging
- Easier to add features

---

## Testing

### Example: Testing Campaign Generation

**BEFORE** ❌
```javascript
// Can't test because everything is mixed
function test_triggerAICampaign() {
    // How do we test this without calling real API?
    // How do we check if DOM was updated correctly?
    // What if localStorage doesn't exist?
    // Too many dependencies to mock
}
```

**AFTER** ✅
```javascript
// Easy to test - pure functions
test('should generate campaign with valid topic', async () => {
    const campaign = await CampaignController.generateCampaign('fitness');
    
    expect(campaign).toBeDefined();
    expect(campaign.hook).toBeTruthy();
    expect(campaign.hashtags.length).toBeGreaterThan(0);
});

test('should fallback when AI fails', async () => {
    // Mock AIService to throw error
    jest.spyOn(AIService, 'generateCompletion').mockRejectedValueOnce(
        new Error('API Error')
    );
    
    const campaign = await CampaignController.generateCampaign('test');
    expect(campaign).toBeDefined();  // Should have fallback
});

test('should apply campaign to canvas', async () => {
    const campaign = { hook: 'Test', problem: 'Test problem', ...};
    const result = CampaignController.applyCampaignToCanvas(campaign);
    
    expect(result).toBe(true);
    expect(appState.canvas.elements.length).toBeGreaterThan(0);
});
```

---

## Summary: Key Improvements

| Aspect | Before | After |
|--------|--------|-------|
| Global functions | 50+ | 3 modules |
| State location | Scattered | Centralized |
| Error handling | Silent failures | User feedback |
| Testing | Very hard | Easy |
| Undo/Redo | No | Built-in |
| Auto-save | No | localStorage |
| Code duplication | High | Low |
| Debugging | Difficult | Simple |
| Maintainability | Poor | Excellent |
| Team onboarding | Hard | Easy |

---

## Next: Implementation

Now that you understand the changes, go to **MIGRATION_GUIDE.md** for step-by-step implementation instructions.

🚀 Ready to implement?
