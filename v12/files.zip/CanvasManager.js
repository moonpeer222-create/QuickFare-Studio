/**
 * Canvas Manager
 * Encapsulates all canvas manipulation logic
 * Replaces window.addTextObj, window.addCardObj, etc.
 */

import { appState } from './appState.js';
import { showToast } from './ui.js';

export class CanvasManager {
    constructor(artboardSelector = '#artboard') {
        this.artboard = document.querySelector(artboardSelector);
        if (!this.artboard) {
            throw new Error(`Artboard element not found: ${artboardSelector}`);
        }
        this.setupDragAndDrop();
    }

    // ============ TEXT ELEMENT ============

    /**
     * Add a text element to canvas
     * @param {Object} config - Configuration object
     * @returns {HTMLElement} The created element
     */
    addText(config) {
        const {
            text = 'TYPE NOW',
            top = '100px',
            left = '80px',
            width = '800px',
            fontSize = '80px',
            fontFamily = 'Anton',
            color = '#fff',
            letterSpacing = '0px',
            lineHeight = '1.1',
            textAlign = 'left',
            textStroke = '0px transparent'
        } = config;

        const div = document.createElement('div');
        div.className = 'element el-text';
        div.innerHTML = this.escapeHTML(text);

        Object.assign(div.style, {
            top,
            left,
            width,
            fontSize,
            fontFamily,
            color,
            letterSpacing,
            lineHeight,
            textAlign,
            webkitTextStroke: textStroke,
            zIndex: ++appState.canvas.maxZIndex
        });

        this.artboard.appendChild(div);
        this.makeElementDraggable(div);
        this.selectElement(div);

        // Add to state
        appState.addCanvasElement({
            type: 'text',
            element: div,
            config: { text, top, left, width, fontSize, fontFamily, color, letterSpacing, lineHeight, textAlign, textStroke }
        });

        return div;
    }

    // ============ CARD ELEMENT ============

    /**
     * Add a card/box element to canvas
     * @param {Object} config - Configuration object
     * @returns {HTMLElement} The created element
     */
    addCard(config) {
        const {
            text = 'Highlight target logic here clearly to engage readers seamlessly with your new output.',
            top = '100px',
            left = '80px',
            width = '600px',
            borderRadius = '20px',
            backgroundColor = 'rgba(18,20,25,0.85)',
            padding = '20px'
        } = config;

        const div = document.createElement('div');
        div.className = 'element el-card';
        div.innerHTML = this.escapeHTML(text);

        Object.assign(div.style, {
            top,
            left,
            width,
            borderRadius,
            backgroundColor,
            padding,
            zIndex: ++appState.canvas.maxZIndex
        });

        this.artboard.appendChild(div);
        this.makeElementDraggable(div);
        this.selectElement(div);

        appState.addCanvasElement({
            type: 'card',
            element: div,
            config: { text, top, left, width, borderRadius, backgroundColor, padding }
        });

        return div;
    }

    // ============ IMAGE ELEMENT ============

    /**
     * Add an image element to canvas
     * @param {Object} config - Configuration object
     * @returns {HTMLElement} The created element
     */
    addImage(config) {
        const {
            url,
            top = '100px',
            left = '80px',
            width = '400px',
            borderRadius = '0px'
        } = config;

        if (!url) {
            throw new Error('Image URL is required');
        }

        const img = document.createElement('img');
        img.className = 'element el-image';
        img.src = url;
        img.crossOrigin = 'anonymous';
        img.draggable = false;

        Object.assign(img.style, {
            top,
            left,
            width,
            borderRadius,
            zIndex: ++appState.canvas.maxZIndex
        });

        this.artboard.appendChild(img);
        this.makeElementDraggable(img);
        this.selectElement(img);

        appState.addCanvasElement({
            type: 'image',
            element: img,
            config: { url, top, left, width, borderRadius }
        });

        return img;
    }

    // ============ ELEMENT MANIPULATION ============

    /**
     * Select an element on canvas
     */
    selectElement(element) {
        // Remove previous selection
        this.artboard.querySelectorAll('.element.selected').forEach(el => {
            el.classList.remove('selected');
        });

        // Add selection to new element
        if (element) {
            element.classList.add('selected');
            appState.selectElement(element.id);
        }
    }

    /**
     * Delete an element from canvas
     */
    deleteElement(element) {
        element.remove();
        appState.removeCanvasElement(element.id);
        showToast('Element deleted');
    }

    /**
     * Clear all elements from canvas
     */
    clearAll() {
        this.artboard.querySelectorAll('.element').forEach(el => el.remove());
        appState.clearCanvasElements();
        showToast('Canvas cleared');
    }

    /**
     * Get all canvas elements
     */
    getElements() {
        return Array.from(this.artboard.querySelectorAll('.element'));
    }

    /**
     * Update element properties
     */
    updateElement(element, updates) {
        Object.assign(element.style, updates);
        appState.updateCanvasElement(element.id, { updates });
    }

    // ============ DRAG AND DROP ============

    /**
     * Make element draggable
     * @private
     */
    makeElementDraggable(element) {
        let isDragging = false;
        let startX, startY, startLeft, startTop;

        element.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            startLeft = element.offsetLeft;
            startTop = element.offsetTop;

            this.selectElement(element);

            document.addEventListener('mousemove', this.onDrag.bind(this, element, startX, startY, startLeft, startTop));
            document.addEventListener('mouseup', () => {
                isDragging = false;
                document.removeEventListener('mousemove', this.onDrag);
                appState.saveCanvasState(); // Save after drag
            });
        });
    }

    /**
     * Handle drag event
     * @private
     */
    onDrag(element, startX, startY, startLeft, startTop, e) {
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;

        element.style.left = (startLeft + deltaX) + 'px';
        element.style.top = (startTop + deltaY) + 'px';
    }

    /**
     * Setup drag and drop for files
     * @private
     */
    setupDragAndDrop() {
        this.artboard.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.artboard.style.borderColor = 'var(--accent)';
        });

        this.artboard.addEventListener('dragleave', (e) => {
            e.preventDefault();
            this.artboard.style.borderColor = '';
        });

        this.artboard.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.artboard.style.borderColor = '';

            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleDroppedFiles(files);
            }
        });
    }

    /**
     * Handle dropped files
     * @private
     */
    handleDroppedFiles(files) {
        Array.from(files).forEach(file => {
            if (!file.type.startsWith('image/')) {
                showToast('Only image files are supported', true);
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                this.addImage({
                    url: e.target.result,
                    top: '50px',
                    left: '50px',
                    width: '200px'
                });
                showToast('Image added to canvas');
            };
            reader.onerror = () => {
                showToast('Failed to read image', true);
            };
            reader.readAsDataURL(file);
        });
    }

    // ============ EXPORT ============

    /**
     * Export canvas as image
     * @param {string} format - 'image/png' or 'image/jpeg'
     * @returns {Promise<Blob>}
     */
    async exportAsImage(format = 'image/png') {
        try {
            appState.setLoading(true, 'Exporting canvas...');

            const canvas = await html2canvas(this.artboard, {
                backgroundColor: '#ffffff',
                scale: 2,
                useCORS: true
            });

            return new Promise((resolve) => {
                canvas.toBlob(blob => {
                    appState.setLoading(false);
                    resolve(blob);
                }, format, 0.95);
            });
        } catch (error) {
            appState.setLoading(false);
            appState.setError(error);
            throw error;
        }
    }

    /**
     * Download canvas as image
     */
    async downloadAsImage(fileName = 'quickfare-design', format = 'image/png') {
        try {
            const blob = await this.exportAsImage(format);
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName + (format === 'image/jpeg' ? '.jpg' : '.png');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            showToast('Image downloaded successfully!');
        } catch (error) {
            showToast('Failed to download image', true);
        }
    }

    // ============ UTILITIES ============

    /**
     * Escape HTML to prevent XSS
     * @private
     */
    escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Get canvas dimensions
     */
    getDimensions() {
        return {
            width: this.artboard.offsetWidth,
            height: this.artboard.offsetHeight
        };
    }

    /**
     * Set canvas dimensions
     */
    setDimensions(width, height) {
        this.artboard.style.width = width + 'px';
        this.artboard.style.height = height + 'px';
        appState.canvas.artboardWidth = width;
        appState.canvas.artboardHeight = height;
    }

    /**
     * Apply preset dimensions
     */
    applyPreset(presetName) {
        const presets = {
            'insta-square': { width: 1080, height: 1080 },
            'insta-portrait': { width: 1080, height: 1350 },
            'insta-story': { width: 1080, height: 1920 },
            'fb-ad': { width: 1200, height: 628 },
            'ebook-cover': { width: 1748, height: 2480 }
        };

        const preset = presets[presetName];
        if (preset) {
            this.setDimensions(preset.width, preset.height);
            showToast(`Canvas resized to ${presetName}`);
        }
    }
}

// Create global singleton
export const canvasManager = new CanvasManager('#artboard');

// Expose to window for easy access in event handlers
window.canvasManager = canvasManager;
