/**
 * Central State Management System
 * Eliminates global window pollution and provides single source of truth
 */

class AppState {
    constructor() {
        // Canvas state
        this.canvas = {
            elements: [],
            selectedElement: null,
            elementCount: 1000,
            maxZIndex: 20,
            artboardWidth: 1080,
            artboardHeight: 1080,
            history: [],
            historyIndex: -1
        };

        // UI state
        this.ui = {
            activeTab: 'design',
            theme: 'dark',
            sidebarOpen: true,
            selectedTemplate: null
        };

        // App state
        this.app = {
            isLoading: false,
            currentOperation: null,
            lastError: null
        };

        // Subscribers for reactive updates
        this.subscribers = {
            canvas: [],
            ui: [],
            app: []
        };
    }

    /**
     * Subscribe to state changes for a specific section
     * @param {string} section - 'canvas', 'ui', or 'app'
     * @param {Function} callback - Called when state updates
     * @returns {Function} Unsubscribe function
     */
    subscribe(section, callback) {
        if (!this.subscribers[section]) {
            console.warn(`Unknown state section: ${section}`);
            return () => {};
        }

        this.subscribers[section].push(callback);

        // Return unsubscribe function
        return () => {
            this.subscribers[section] = this.subscribers[section].filter(cb => cb !== callback);
        };
    }

    /**
     * Notify all subscribers of changes
     * @private
     */
    notify(section) {
        if (this.subscribers[section]) {
            this.subscribers[section].forEach(callback => {
                try {
                    callback(this[section], this);
                } catch (error) {
                    console.error(`Subscriber error in ${section}:`, error);
                }
            });
        }
    }

    // ============ CANVAS STATE METHODS ============

    addCanvasElement(element) {
        this.canvas.elements.push({
            id: `el-${++this.canvas.elementCount}`,
            ...element,
            zIndex: ++this.canvas.maxZIndex
        });
        this.saveToHistory();
        this.notify('canvas');
        return this.canvas.elements[this.canvas.elements.length - 1];
    }

    removeCanvasElement(elementId) {
        const index = this.canvas.elements.findIndex(el => el.id === elementId);
        if (index !== -1) {
            this.canvas.elements.splice(index, 1);
            this.saveToHistory();
            this.notify('canvas');
        }
    }

    updateCanvasElement(elementId, updates) {
        const element = this.canvas.elements.find(el => el.id === elementId);
        if (element) {
            Object.assign(element, updates);
            this.saveToHistory();
            this.notify('canvas');
        }
    }

    selectElement(elementId) {
        this.canvas.selectedElement = elementId;
        this.notify('canvas');
    }

    clearCanvasElements() {
        this.canvas.elements = [];
        this.canvas.selectedElement = null;
        this.canvas.history = [];
        this.canvas.historyIndex = -1;
        this.saveToHistory();
        this.notify('canvas');
    }

    getCanvasElement(elementId) {
        return this.canvas.elements.find(el => el.id === elementId);
    }

    getAllCanvasElements() {
        return [...this.canvas.elements];
    }

    // ============ HISTORY/UNDO-REDO ============

    saveToHistory() {
        // Remove any redo history
        this.canvas.history = this.canvas.history.slice(0, this.canvas.historyIndex + 1);
        // Save current state
        this.canvas.history.push(JSON.parse(JSON.stringify(this.canvas.elements)));
        this.canvas.historyIndex++;
    }

    undo() {
        if (this.canvas.historyIndex > 0) {
            this.canvas.historyIndex--;
            this.canvas.elements = JSON.parse(JSON.stringify(this.canvas.history[this.canvas.historyIndex]));
            this.notify('canvas');
        }
    }

    redo() {
        if (this.canvas.historyIndex < this.canvas.history.length - 1) {
            this.canvas.historyIndex++;
            this.canvas.elements = JSON.parse(JSON.stringify(this.canvas.history[this.canvas.historyIndex]));
            this.notify('canvas');
        }
    }

    // ============ UI STATE METHODS ============

    switchTab(tabName) {
        this.ui.activeTab = tabName;
        this.notify('ui');
    }

    toggleTheme() {
        this.ui.theme = this.ui.theme === 'dark' ? 'light' : 'dark';
        this.notify('ui');
        this.persistUIState();
    }

    setSelectedTemplate(templateName) {
        this.ui.selectedTemplate = templateName;
        this.notify('ui');
    }

    // ============ APP STATE METHODS ============

    setLoading(isLoading, operation = null) {
        this.app.isLoading = isLoading;
        this.app.currentOperation = operation;
        this.notify('app');
    }

    setError(error) {
        this.app.lastError = error ? {
            message: error.message || String(error),
            timestamp: new Date(),
            code: error.code || 'UNKNOWN_ERROR'
        } : null;
        this.notify('app');
    }

    clearError() {
        this.app.lastError = null;
        this.notify('app');
    }

    // ============ PERSISTENCE ============

    /**
     * Save canvas state to localStorage
     */
    saveCanvasState() {
        try {
            localStorage.setItem('quickfare_canvas_state', JSON.stringify({
                elements: this.canvas.elements,
                dimensions: {
                    width: this.canvas.artboardWidth,
                    height: this.canvas.artboardHeight
                },
                savedAt: new Date().toISOString()
            }));
        } catch (error) {
            console.error('Failed to save canvas state:', error);
        }
    }

    /**
     * Load canvas state from localStorage
     */
    loadCanvasState() {
        try {
            const saved = localStorage.getItem('quickfare_canvas_state');
            if (saved) {
                const data = JSON.parse(saved);
                this.canvas.elements = data.elements || [];
                this.canvas.artboardWidth = data.dimensions?.width || 1080;
                this.canvas.artboardHeight = data.dimensions?.height || 1080;
                this.saveToHistory();
                this.notify('canvas');
                return true;
            }
        } catch (error) {
            console.error('Failed to load canvas state:', error);
        }
        return false;
    }

    /**
     * Save UI preferences to localStorage
     */
    persistUIState() {
        try {
            localStorage.setItem('quickfare_ui_state', JSON.stringify({
                theme: this.ui.theme,
                sidebarOpen: this.ui.sidebarOpen
            }));
        } catch (error) {
            console.error('Failed to persist UI state:', error);
        }
    }

    /**
     * Load UI preferences from localStorage
     */
    restoreUIState() {
        try {
            const saved = localStorage.getItem('quickfare_ui_state');
            if (saved) {
                const data = JSON.parse(saved);
                this.ui.theme = data.theme || 'dark';
                this.ui.sidebarOpen = data.sidebarOpen !== false;
                this.notify('ui');
            }
        } catch (error) {
            console.error('Failed to restore UI state:', error);
        }
    }

    // ============ UTILITIES ============

    /**
     * Get full state snapshot (for debugging)
     */
    getSnapshot() {
        return {
            canvas: this.canvas,
            ui: this.ui,
            app: this.app
        };
    }

    /**
     * Reset all state to initial values
     */
    reset() {
        this.canvas = {
            elements: [],
            selectedElement: null,
            elementCount: 1000,
            maxZIndex: 20,
            artboardWidth: 1080,
            artboardHeight: 1080,
            history: [],
            historyIndex: -1
        };
        this.ui = {
            activeTab: 'design',
            theme: 'dark',
            sidebarOpen: true,
            selectedTemplate: null
        };
        this.app = {
            isLoading: false,
            currentOperation: null,
            lastError: null
        };
        this.notify('canvas');
        this.notify('ui');
        this.notify('app');
    }
}

// Create global singleton instance
export const appState = new AppState();

// Make available globally for debugging (remove in production)
if (process.env.NODE_ENV !== 'production') {
    window.__appState = appState;
}
