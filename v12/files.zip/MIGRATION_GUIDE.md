# QuickFare-Studio: Migration Guide (This Week)

## 🎯 Implementation Timeline: 3-4 Days

This guide walks you through implementing the refactored architecture **without breaking** your current application.

---

## Phase 1: Setup (30 minutes)

### Step 1: Create New Directory Structure

```bash
js/
├── appState.js              (NEW - central state)
├── CanvasManager.js         (NEW - canvas operations)
├── CampaignController.js    (NEW - business logic)
├── ui.js                    (REPLACE - improved utilities)
├── services/
│   ├── AIService.js         (keep existing, but secure it later)
│   ├── PexelsService.js
│   └── CanvaService.js
├── config.js                (keep for now)
├── state.js                 (can deprecate after migration)
├── canvas.js                (can deprecate after migration)
├── api.js                   (can deprecate after migration)
```

### Step 2: Copy New Files

Copy these three new files to your `js/` directory:
1. `appState.js` - Central state management
2. `CanvasManager.js` - Canvas manipulation API
3. `CampaignController.js` - Campaign business logic

Copy the refactored `ui.js` as a replacement.

---

## Phase 2: Update index.html (1-2 hours)

### Old Approach (What You Have)
```html
<script src="js/config.js"></script>
<script src="js/state.js"></script>
<script src="js/ui.js"></script>
<script src="js/canvas.js"></script>
<script src="js/api.js"></script>
<script src="js/services/AIService.js"></script>
<!-- ... all global functions in window -->
```

### New Approach (Refactored)
```html
<!-- Services (unchanged for now) -->
<script type="module" src="js/services/AIService.js"></script>

<!-- Core modules (new architecture) -->
<script type="module" src="js/appState.js"></script>
<script type="module" src="js/ui.js"></script>
<script type="module" src="js/CanvasManager.js"></script>
<script type="module" src="js/CampaignController.js"></script>

<!-- Main app initialization -->
<script type="module">
    import { appState } from './js/appState.js';
    import { canvasManager } from './js/CanvasManager.js';
    import { CampaignController } from './js/CampaignController.js';
    import { initializeTheme } from './js/ui.js';

    // Initialize
    window.appState = appState;
    window.canvasManager = canvasManager;
    window.CampaignController = CampaignController;
    
    initializeTheme();
    appState.restoreUIState();
    appState.loadCanvasState();
</script>
```

---

## Phase 3: Update HTML Event Handlers (30-45 minutes)

### Example 1: Button onclick for Adding Text

**Before** (Old):
```html
<button onclick="addElement('text')">Add Text</button>
```

**After** (New):
```html
<button onclick="canvasManager.addText({ text: 'TYPE NOW', top: '100px', left: '80px', width: '800px' })">Add Text</button>
```

### Example 2: Clear Canvas

**Before**:
```html
<button onclick="clearCanvasElements()">Clear Canvas</button>
```

**After**:
```html
<button onclick="canvasManager.clearAll()">Clear Canvas</button>
```

### Example 3: Add Card

**Before**:
```html
<button onclick="addElement('card')">Add Card</button>
```

**After**:
```html
<button onclick="canvasManager.addCard({ text: 'Your text here', top: '100px', left: '80px' })">Add Card</button>
```

### Example 4: Theme Toggle

**Before**:
```html
<button onclick="toggleTheme()" title="Toggle Light/Dark Theme">
    <i class="fas fa-moon" id="theme-icon"></i>
</button>
```

**After**:
```html
<button onclick="toggleTheme()" title="Toggle Light/Dark Theme">
    <i class="fas fa-moon" id="theme-icon"></i>
</button>

<script type="module">
import { toggleTheme } from './js/ui.js';
window.toggleTheme = toggleTheme;
</script>
```

### Example 5: Tab Switching

**Before**:
```html
<button onclick="switchTab('design')">Design Suite</button>
```

**After**:
```html
<button onclick="appState.switchTab('design'); updateTabVisibility('design')">Design Suite</button>

<script type="module">
import { appState } from './js/appState.js';

function updateTabVisibility(tabName) {
    document.querySelectorAll('.tab-content').forEach(el => {
        el.style.display = 'none';
    });
    const tab = document.getElementById(`tab-${tabName}`);
    if (tab) tab.style.display = 'block';
}

window.updateTabVisibility = updateTabVisibility;
</script>
```

---

## Phase 4: Update Campaign Generation (45 minutes)

### Find This Section in Your HTML:
```html
<div id="ai-results"></div>
<button onclick="triggerAICampaign()">Generate Campaign</button>
```

### Replace With This:
```html
<div id="ai-results"></div>
<button onclick="generateCampaignUI()">Generate Campaign</button>

<script type="module">
import { CampaignController } from './js/CampaignController.js';
import { showToast } from './js/ui.js';

window.generateCampaignUI = async function() {
    const topic = document.getElementById('ai-topic-strategy').value;
    
    if (!topic) {
        showToast('Please enter a topic', true);
        return;
    }

    const campaign = await CampaignController.generateCampaign(topic);
    
    if (campaign) {
        // Display results
        const resultsDiv = document.getElementById('ai-results');
        resultsDiv.innerHTML = `
            <div style="padding: 15px; background: rgba(0,240,255,0.1); border-radius: 8px;">
                <h4>🔥 VIRAL TRIGGER HOOK</h4>
                <p>${campaign.hook}</p>
                <h4>🧠 DIRECT AD FRAMEWORK</h4>
                <p><b>Problem:</b> ${campaign.problem}<br>
                   <b>Action:</b> ${campaign.aggression}<br>
                   <b>Solution:</b> ${campaign.solution}</p>
                <h4>🎯 HASHTAGS</h4>
                <p>${campaign.hashtags.join(' ')}</p>
                <button class="btn btn-magic" style="width: 100%; margin-top: 15px;" 
                        onclick="CampaignController.applyCampaignToCanvas(window.lastCampaign)">
                    ✨ Apply to Canvas
                </button>
            </div>
        `;
        window.lastCampaign = campaign; // Store for applying
    }
};
</script>
```

---

## Phase 5: Update Undo/Redo Functions (15 minutes)

### Old Approach:
```html
<button onclick="undo()">Undo</button>
<button onclick="redo()">Redo</button>

<script>
// Functions in api.js
function undo() { /* ... */ }
function redo() { /* ... */ }
</script>
```

### New Approach:
```html
<button onclick="appState.undo()">Undo</button>
<button onclick="appState.redo()">Redo</button>

<script type="module">
import { appState } from './js/appState.js';
window.appState = appState;
</script>
```

---

## Phase 6: Update Export Functions (15 minutes)

### Old Approach:
```html
<button onclick="exportDesign()">Save Final Asset</button>

<script>
function exportDesign() {
    html2canvas(document.getElementById('artboard')).then(canvas => {
        // ...
    });
}
</script>
```

### New Approach:
```html
<select id="export-format">
    <option value="image/png">PNG (Lossless)</option>
    <option value="image/jpeg">JPEG (Compressed)</option>
</select>
<button onclick="downloadDesign()">Save Final Asset</button>

<script type="module">
import { canvasManager } from './js/CanvasManager.js';

window.downloadDesign = async function() {
    const format = document.getElementById('export-format').value;
    await canvasManager.downloadAsImage('quickfare-design', format);
};
</script>
```

---

## Phase 7: Update Template Loading (30 minutes)

### Old Approach:
```html
<button onclick="loadTemplate('cover')">E-Book Cover</button>

<script>
function loadTemplate(name) {
    clearCanvasElements();
    // hard-coded logic for each template
    if (name === 'cover') {
        addTextObj(...);
        addCardObj(...);
    }
}
</script>
```

### New Approach:
```html
<button onclick="applyTemplate('cover')">E-Book Cover</button>

<script type="module">
import { canvasManager } from './js/CanvasManager.js';
import { appState } from './js/appState.js';

const TEMPLATES = {
    cover: {
        name: 'E-Book Cover',
        elements: [
            {
                type: 'text',
                config: {
                    text: 'YOUR TITLE HERE',
                    top: '200px',
                    left: '50px',
                    width: '900px',
                    fontSize: '80px',
                    fontFamily: 'Anton'
                }
            },
            {
                type: 'card',
                config: {
                    text: 'Subtitle and description goes here',
                    top: '450px',
                    left: '50px',
                    width: '900px'
                }
            }
        ]
    },
    quote: {
        name: 'Authority Quote',
        elements: [
            {
                type: 'card',
                config: {
                    text: '"Your powerful quote goes here"',
                    top: '300px',
                    left: '50px',
                    width: '900px'
                }
            }
        ]
    }
};

window.applyTemplate = function(templateName) {
    const template = TEMPLATES[templateName];
    if (!template) return;

    canvasManager.clearAll();
    
    template.elements.forEach(element => {
        if (element.type === 'text') {
            canvasManager.addText(element.config);
        } else if (element.type === 'card') {
            canvasManager.addCard(element.config);
        }
    });
    
    appState.saveCanvasState();
};
</script>
```

---

## Phase 8: Update Pexels Image Search (30 minutes)

### Old Approach:
```html
<input type="text" id="pexels-search" placeholder="Search images...">
<button onclick="fetchPexels()">Search</button>

<script>
async function fetchPexels() {
    const query = document.getElementById('pexels-search').value;
    // API call logic mixed with UI
}
</script>
```

### New Approach:
```html
<input type="text" id="pexels-search" placeholder="Search images...">
<button onclick="searchAndDisplayImages()">Search</button>
<div id="image-results" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;"></div>

<script type="module">
import { PexelsService } from './js/services/PexelsService.js';
import { canvasManager } from './js/CanvasManager.js';
import { showToast } from './js/ui.js';

window.searchAndDisplayImages = async function() {
    const query = document.getElementById('pexels-search').value;
    
    if (!query) {
        showToast('Enter a search term', true);
        return;
    }

    try {
        const images = await PexelsService.search(query);
        const resultsDiv = document.getElementById('image-results');
        resultsDiv.innerHTML = '';
        
        images.forEach(photo => {
            const img = document.createElement('img');
            img.src = photo.src.medium;
            img.style.cssText = 'cursor: pointer; width: 100%; border-radius: 8px;';
            img.onclick = () => {
                canvasManager.addImage({
                    url: photo.src.large2x,
                    top: '50px',
                    left: '50px',
                    width: '300px'
                });
                showToast('Image added to canvas');
            };
            resultsDiv.appendChild(img);
        });
    } catch (error) {
        showToast(`Search failed: ${error.message}`, true);
    }
};
</script>
```

---

## Phase 9: Subscribe to State Changes (30 minutes)

This enables reactive UI updates when state changes.

```html
<div id="element-count">Elements: 0</div>

<script type="module">
import { appState } from './js/appState.js';

// Subscribe to canvas changes
appState.subscribe('canvas', (canvasState) => {
    document.getElementById('element-count').textContent = 
        `Elements: ${canvasState.elements.length}`;
});

// Subscribe to UI changes
appState.subscribe('ui', (uiState) => {
    console.log('Active tab:', uiState.activeTab);
});

// Subscribe to app errors
appState.subscribe('app', (appState) => {
    if (appState.lastError) {
        console.error('App error:', appState.lastError);
    }
});
</script>
```

---

## ✅ Quick Verification Checklist

After implementing these changes, verify:

- [ ] Page loads without console errors
- [ ] Clicking "Add Text" creates text element
- [ ] Clicking "Clear Canvas" removes all elements
- [ ] Theme toggle works (changes dark/light)
- [ ] Undo/Redo buttons work
- [ ] Tab switching works
- [ ] Campaign generation works
- [ ] Image search works
- [ ] Export works
- [ ] Canvas state saves to localStorage
- [ ] No global function pollution in console

---

## Debugging Tips

### Check What's Exposed
Open browser console and run:
```javascript
console.log(Object.keys(window).filter(k => k.startsWith('add') || k.startsWith('clear')))
// Should be much shorter than before!
```

### Check State
```javascript
console.log(appState.getSnapshot())
// Should show clean, organized state structure
```

### Check Subscribers
```javascript
console.log(appState.subscribers)
// Should show all active subscriptions
```

---

## Troubleshooting

### "appState is not defined"
- Make sure you imported it: `import { appState } from './js/appState.js'`
- Make sure it's exposed to window: `window.appState = appState;`

### "canvasManager.addText is not a function"
- Make sure the module imported correctly
- Check that `#artboard` element exists in HTML
- Open console and verify: `console.log(canvasManager)`

### Event handlers not firing
- Make sure you're using the new function names
- Check that modules are loaded as type="module"
- Verify onclick attributes match exported functions

### State not updating UI
- Make sure you subscribed: `appState.subscribe('canvas', callback)`
- Check that callback doesn't throw errors
- Verify state changes are calling `notify()`

---

## Next Steps (Week 2+)

Once Phase 1 is complete:

1. **Security** - Move API keys to backend
2. **Testing** - Add Jest tests for controllers
3. **Performance** - Lazy load libraries
4. **Cleanup** - Remove old api.js, canvas.js files

---

## Questions?

Keep this guide nearby and go **step by step**. You don't need to do everything today - focus on:

**Day 1**: Phases 1-2 (setup + index.html)
**Day 2**: Phases 3-5 (button handlers + undo/redo)
**Day 3**: Phases 6-9 (export + pexels + state)

Good luck! 🚀
